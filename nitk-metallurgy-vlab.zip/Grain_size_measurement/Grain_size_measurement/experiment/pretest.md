## <b> Pre-test</b>
#### Please attempt the following questions

<br>

Q 1. Which of the following is the size of brass grain<br>
a) 0.4mm<br>
<b>b) 0.04mm</b><br>
c) 0.004mm<br>
d) 0.0004mm<br><br>

Q 2. Quartz grains are generally fine or small in shape and size during analysis of quartz.<br>
a) True<br>
<b>b) False</b><br>

Q 3. What is NAE? <br>
a) Number of grains per square inch at 10X magnification.<br>
<b>b) Number of grains per square inch at 100X magnification.</b><br>
c) Number of grains per square inch at 50X magnification.<br>
d) Number of grains per square inch at 500X magnification.<br>

Q 4. In Jefferies Planimetric Method, In equation n=2^(G-1), G represents <br>
a) ASTM grain size number<br>
b) ASTM grain size number<br>
c) ASRN grain size number<br>
<b>d) ASTM grain size number</b><br>

Q 5.The planimetric method which is a grain size measurement method describes… <br>
<b>a) Isothermal transformation diagram</b><br>
b)Density of grains per cubic millimeter volume<br>
c) continuous cooling transformation diagram<br>
d) logarithm scale<br>

Q 6. The relation between average grain size and yield strength is formulated as: σ= σ0+k*d^(-0.5). Where k is a constant called____ <br>
<b>a) Hall-petch slope</b><br>
b) Hall-herald slope<br>
c) James-petch slope<br>
d) James-herald slope<br>

Q 7. In Germany in 1904, Emil Heyn published an intercept approach for measuring grain size. In this method_________ <br>
<b>a) True line length is divided by the number of grains intercepted by the line.</b><br>
b) True line length is divided by the number density of grains intercepted by the line.<br>
c) True line length is divided by the area density of grains intercepted by the line.<br>
d) True line length is divided by the average length of grains intercepted by the line.<br>

Q 8. What is Grain intercept count?<br>
a) Determination of the number of times a test line touches individual grains on the polish plane.<br>
b) Determination of the number of times a test line does not touch individual grains on the polish plane.<br>
<b>c) Determination of the number of times a test line cuts through individual grains on the polish plane.</b><br>

<!-- Q 9. If the quenching medium cools the specimen at a faster rate, cracks might occur in the specimen. <br>
<b>a) true</b><br>
b) false<br> -->
<!-- 
Q 10. During quenching, there could be a mechanism like_____ <br>
<b>a) vacancy diffusion</b><br>
b) vacancy formation<br>
c) grain diffusion<br>
d) grain boundary distortion<br> -->

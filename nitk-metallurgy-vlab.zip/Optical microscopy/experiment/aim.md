To obtain microstructures of non ferrous alloys like Solder alloy (Pb-Sn) and Brass.

## Post test
<br>
Q 1.  A first solid phase results in a second solid plus another third solid phase upon heating during ___________ reaction.<br>
a. Eutectoid<br>
<b>b. Peritectoid</b> <br>
c. Peritectic<br>
d. Eutectic<br>

Q 2.  Which phase will crystallize first just below the liquidus line?<br>
a. (L+α) phase<br>
b. (L+β) phase<br>
<b>c. α phase</b><br>
d. β phase<br>

Q 3.  At what temperature, all liquid and α will convert to β?<br>
a. Eutectic temperature<br>
b. Eutectoid temperature<br>
c. Peritectoid temperature<br>
<b>d. Peritectic temperature</b> <br>

Q 4.  Any composition left and right of P will generate<br>
a. Excess of liquid and α<br>
b. Excess of liquid and β<br>
<b>c. Excess of α and liquid</b> <br>
d. Excess of β and liquid<br>

Q 5.  How much copper is present in deoxidized copper?<br>
a. > 99.9%<br>
<b>b. > 99.85%</b> <br>
c. > 99.5%<br>
d. > 99.35%<br>


Q 6.  What is the melting point of Copper? <br>
<b>a. 1084 </b> <br>
b. 600<br>
c. 419<br>
d. 2562<br>

Q 7.  Brass is an alloy of copper and<br>
a. Tin<br>
b. Tin and zinc<br>
c. Nickel<br>
<b>d. Zinc  </b> <br>

Q 8.  α brasses contain _______ of zinc.<br>
a. 0%<br>
<b>b. <=36%</b> <br>
c. >36%<br>
d. 100%<br>

Q 9.  Yellow metal is more commonly known as<br>
a. Cartridge brass<br>
b. Naval brass<br>
<b>c. Muntz metal</b> <br>
d. Admiralty brass<br>

Q 10.  Which brass alloy has high tensile strength and can be used for cast molding?<br>
<b>a. Manganese brass</b> <br>
b. Free cutting brass<br>
c. Standard brass<br>
d. Gilding metal<br>

Q 11.  Which brass alloy is used to make imitation jewelry and decorative work?<br>
<b>a. Gilding metal </b> <br>
b. Standard brass<br>
c. Admiralty brass<br>
d. Free cutting brass<br>

Q 12.  Which brass alloy is suitable for high-speed machining?<br>
a. Gilding metal<br>
<b>b. Leaded brass </b> <br>
c. High tensile brass<br>
d. Muntz metal<br>
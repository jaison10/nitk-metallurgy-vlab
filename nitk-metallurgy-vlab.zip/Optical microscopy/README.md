## Introduction (Round 0)

<br>

<b>Discipline | <b>Metallurgical and Materials Engineering
:--|:--|
<b> Lab | <b> Physical Metallurgy Lab
<b> Experiment|     <b> 4. Optical microscopy of Non ferrous samples

<h5> About the Experiment : </h5> <br>

This experiment allows us to obtain and observe microstructures of non ferrous alloys like Solder alloy (Pb-Sn) and Brass.  

<b>Name of Developer | <b> Dr. Pruthviraj U
:--|:--|
<b> Institute | <b> National Institute of Technology Karnataka, Surathkal
<b> Email id|     <b> pruthviu@nitk.edu.in
<b> Department | Applied Mechanics and Hydraulics

#### Contributors List

Sr No | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | Rohit V Halakatti | Student | Information Technology | National Institute of Technology Karnataka, Surathkal | rvhalakatti123@gmail.com
2 | M R Ashrit | Student | Computer Science | National Institute of Technology Karnataka, Surathkal |16co122.ashrit@nitk.edu.in
3 | Jatin Patil | Student | Metallurgical and Materials Engineering | National Institute of Technology Karnataka, Surathkal |jatin.171mt017@nitk.edu.in
4 | Iteesha V A | Student | Metallurgical and Materials Engineering | National Institute of Technology Karnataka, Surathkal |iteesha.171mt016@nitk.edu.in
5 | Arjun Krishna | Student | Metallurgical and Materials Engineering | National Institute of Technology Karnataka, Surathkal |arjunkrishna.171mt005@nitk.edu.in
6 | Aishwarya Hegde | Student | Applied Mechanics and Hydraulics | National Institute of Technology Karnataka, Surathkal |aishwaryahegde29@gmail.com
7 | Aishwarya Shetty | Student | Applied Mechanics and Hydraulics | National Institute of Technology Karnataka, Surathkal |aishwarya.shetty1995@gmail.com
8 | Haneena | Student | Applied Mechanics and Hydraulics | National Institute of Technology Karnataka, Surathkal |haneenaatheeq@gmail.com
9 | Jaison DSouza B | Student | Applied Mechanics and Hydraulics | National Institute of Technology Karnataka, Surathkal |jaisonj1010@gmail.com

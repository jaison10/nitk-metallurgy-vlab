## Post test
<br>
Q 1. )In calibration we use a _______to determine the true linear magnification for each objective, eyepiece and bellows<br>
<b>a) stage micrometer</b> <br>
b) stage nanometer<br>
c) stage thermometer<br>
d) stage millimeter <br><br>

Q 2. NA =f(N Inside +N intercepted/2). In this equation ‘f’ represents ….. <br>
a) James’ multiplier<br>
b) Thomsons’ multiplier<br>
<b>c) Jeffries’ multiplier</b><br>
d) Albert multiplier<br>

Q 3. Which of the following is a precaution before measurement in the Hilliard Single Circle procedure?<br>
a) Test circle radius must be smaller than the largest observed grain.<br>
<b>b) Test circle diameter should never be smaller the the largest observed grain.</b><br>
c) Test circle diameter must be equal to the largest observed grain.<br>
d) Test circle diameter must be smaller than the smallest observed grain.<br>

Q 4. In Abrams Three-Circle procedure , The test pattern consists of three concentric and equally spaced circles of circumference____<br>
<b>a) 500mm</b><br>
b) 400mm<br>
c) 600mm<br>
d) 300mm<br>

Q 5. The precision and bias of grain size measurements depends on…. <br>
a) degree of hardness of the specimens selected and the areas on the polish planes <br>
b) density of the specimens selected and the areas on the polish planes <br>
<b>c) Representativeness of the specimens selected and the areas on the polish planes</b> <br>
d) thickness of the specimens selected and the areas on the polish planes<br>

Q 6. The region closest to the weld metal will have larger diameter and is called…..<br>
a) Fine grain heat affected zone<br>
b) Hot grain heat affected zone<br>
<b>c) Coarse grain heat affected zone</b><br>
d) cold grain heat affected zone<br>

Q 7. )Which of the following instrument can be used for measuring Grain size? <br>
a) Electrical microscope<br>
<b>b) Optical microscope</b><br>
c) Compound microscope<br>
d) laser microscope<br>

Q 8. What is the approximate size of ferrite grain? <br>
<b>a) 10 μm</b><br>
b) 1000 μm<br>
c) 50 μm <br>
d) 500 μm <br>

<!-- Q 9. For hardening of steel by quenching, the steel is cooled in ________ <br>
a) furnace<br>
b) still air<br>
<b>c) oil bath</b><br>
d) cooling tower<br> -->

<!-- Q 10. The cooling rate must be _______ the critical cooling rate for hardening of steel by quenching. <br>
<b>a) higher than</b><br>
b) lower than<br>
c) equal to<br>
d) half of<br> -->

1. NITK Surathkal Physical Metallurgy lab manual<br>
2. Metallographer's Guide: Practices and Procedures for Irons and Steels. <br>
  (By Brucee L. Bramfitt, Arlan O. Benscoter)<br>
3. Physical Metallurgy Princples<br>
  (By Robert E. Reed-Hill)

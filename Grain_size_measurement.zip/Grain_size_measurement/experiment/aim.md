To measure the grain size of the given sample using<br>
<ul>
<li>ASTM Grain Size Number</li>
<li>Jefferies Planimetric Method</li>
<li>Heyn's Intercept method</li>
</ul>
